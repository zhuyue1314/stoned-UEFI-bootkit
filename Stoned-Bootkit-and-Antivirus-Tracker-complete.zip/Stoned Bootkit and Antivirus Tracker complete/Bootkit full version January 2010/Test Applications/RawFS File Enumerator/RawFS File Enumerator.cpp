// small test application to enumerate all RawFS files

#include "windows.h"
#include "stdio.h"
#include "../../Infector/Source/Error.h"


/* imports */

int RawFS_CheckVolumeExists(HANDLE PhysicalDrive, DWORD & StartSector);
int RawFS_GetFileInfo(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, DWORD & FileSize);
int RawFS_ReadFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE *& Buffer,  DWORD & FileSize);
int RawFS_WriteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE * Buffer,  DWORD FileSize);
int RawFS_FormatVolume(HANDLE PhysicalDrive, DWORD StartSector);
int RawFS_EnumerateFiles(HANDLE PhysicalDrive, DWORD StartSector, void (*Callback)(char * FileName, DWORD Size));

void Callback(char * FileName, DWORD Size);


/* Application Entry */

int wmain(int argc, wchar_t *argv[], wchar_t *envp[])
{
	puts("\n  RawFS Simple File Enumerator\n");
	puts("  Version 0.1  " __DATE__);
	puts("  (C) 2009 Insecurity Systems InSec e.U.\n\n");

    // create a handle to the drive
    HANDLE PhysicalDrive = CreateFile(L"\\\\.\\PHYSICALDRIVE0", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    if (PhysicalDrive == INVALID_HANDLE_VALUE)
    {
        puts("Could not open PhysicalDrive0");
        return 0;
    }

    // open RawFS volume
    DWORD StartSector;
    int Status;
    Status = RawFS_CheckVolumeExists(PhysicalDrive, StartSector);
    if (Status == Error_Windows)
    {
        puts("Unknown Windows error");
        return 0;
    }
    if (Status == RawFS_Not_Bootable)
    {
        puts("Drive is not bootable, thus RawFS is not present");
        return 0;
    }
    if (Status == RawFS_Not_Installed)
    {
        puts("RawFS volume is not present on disk.");
        return 0;
    }

    // Enumerate all files
    RawFS_EnumerateFiles(PhysicalDrive, StartSector, &Callback);

	CloseHandle(PhysicalDrive);

    return 1;
}

void Callback(char * FileName, DWORD Size)
{
    puts(FileName);
}