
// simple disinfector

#include "windows.h"
#include "tchar.h"
#include "../../Infector/Source/Error.h"


/* imports */

void DisinfectDrive(HANDLE PhysicalDrive);
void OutputUserError(int Error);


/* forward declarations */

void DisinfectDrive(wchar_t * DriveName);


/* Application Entry */

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
    DisinfectDrive(L"\\\\.\\PHYSICALDRIVE0");
    return 1;
}


/* small wrapper for disinfecting all drives */

void DisinfectDrive(wchar_t * DriveName)
{
    // create a handle to the drive
    HANDLE PhysicalDrive = CreateFile(DriveName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    if (PhysicalDrive == INVALID_HANDLE_VALUE)
    {
        OutputUserError(UserError_DriveOpenError);
        return;
    }

    DisinfectDrive(PhysicalDrive);

	CloseHandle(PhysicalDrive);
}
