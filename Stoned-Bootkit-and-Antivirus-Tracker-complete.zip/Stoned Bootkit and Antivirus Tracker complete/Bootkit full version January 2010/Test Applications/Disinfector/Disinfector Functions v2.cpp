
// Disinfector functions for the Stoned Bootkit v2, "Human knowledge belongs to the world"

#include "windows.h"
#include "../../Infector/Source/Error.h"


/* imports */

int RawFS_CheckVolumeExists(HANDLE PhysicalDrive, DWORD & StartSector);
int RawFS_GetFileInfo(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, DWORD & FileSize);
int RawFS_ReadFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE *& Buffer,  DWORD & FileSize);
int RawFS_WriteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE * Buffer,  DWORD FileSize);
int RawFS_FormatVolume(HANDLE PhysicalDrive, DWORD StartSector);
int RawFS_RemoveVolume(HANDLE PhysicalDrive, DWORD StartSector);

inline void OutputUserError(int Error);

#define MD5_MBR_Backup      "0F13C73AAB0D4E000028038C99D3125A"      // \Master Boot Record.bak
#define MD5_Bootloader      "ddcad6ec9127c41872ee0d0e0df14883"      // \Bootloader


/* forward declarations */

int RestoreBootSector(HANDLE PhysicalDrive, DWORD StartSector);



/* stores all Stoned v2 files via RawFS and writes the boot sector
   errors will only be passed further by this function
*/

void DisinfectDrive(HANDLE PhysicalDrive)
{
    int Status;

    // check if RawFS is already installed and get parameters
    DWORD RawFS_StartSector;
    Status = RawFS_CheckVolumeExists(PhysicalDrive, RawFS_StartSector);
    if (Status == Error_Windows)
    {
        OutputUserError(UserError_FailBootDrive);
        return;
    }
    if (Status == RawFS_Not_Installed || Status == RawFS_Not_Bootable)
    {
        // fine
        MessageBox(NULL, L"Volume was not found to be infected with Stoned v2.", L"Successful", MB_OK);
        return;
    }

    // backup and write the boot sector
    if (RestoreBootSector(PhysicalDrive, RawFS_StartSector) != 2)
        OutputUserError(UserError_RestoreBootSector);

    // remove the RawFS volume
    if (RawFS_RemoveVolume(PhysicalDrive, RawFS_StartSector) != 2)
        OutputUserError(UserError_RemoveVolume);

    MessageBox(NULL, L"Disinfected successfully Stoned Bootkit 2 Public.", L"Successful", MB_OK);
}


/* restores the original bootloader, thus uninstalling Stoned
    return codes:   00 = Windows Error
                    02 = success
*/

int RestoreBootSector(HANDLE PhysicalDrive, DWORD StartSector)
{
    // read the boot sector backup
    BYTE * BootSectorBackup;
    DWORD FileSize;
    int Status;
    Status = RawFS_ReadFile(PhysicalDrive, StartSector, MD5_MBR_Backup, BootSectorBackup,  FileSize);
    if (Status != 2)
        return Status;

    // read the boot sector
    BYTE BootSector[512];
    DWORD NumberOfBytesRead;
    if (SetFilePointer(PhysicalDrive, 0, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER     ||
        !ReadFile(PhysicalDrive, BootSector, 512, &NumberOfBytesRead, NULL) )
        return 0;

    // fix the partition table and disk signature
    memcpy(BootSectorBackup + 0x1BE, BootSector + 0x1BE, 4*16);
    memcpy(BootSectorBackup + 440, BootSector + 440, 6);

#ifndef _DEBUG
    if (SetFilePointer(PhysicalDrive, 0, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER     ||
        !WriteFile(PhysicalDrive, BootSectorBackup, 512, &NumberOfBytesRead, NULL) )
        return 0;
#endif

    VirtualFree(BootSector, 0, MEM_RELEASE);
    return 2;
}

