
// shellcode tester, debug-only

#include "windows.h"
#include "tchar.h"
#include "../../Boot Code/Drivers/Protective Exe Loader/Shellcode/Loader Shellcode.cpp"

typedef struct {
  DWORD Reserved0;
  DWORD Event;
  BYTE ImportsResolved;
  BYTE StartType;
  char FileName[MAX_PATH];
} ShellcodeControlBlock;


/* Application Entry */

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
    void (*Shellcode)(ShellcodeControlBlock * Variable);
    Shellcode  = (void (*)(ShellcodeControlBlock * Variable))(PVOID)&bin_data1;

    DWORD RValue;
    VirtualProtect (&bin_data1, 4096, PAGE_EXECUTE_READWRITE, &RValue);

    ShellcodeControlBlock SCB;
    SCB.Event = 0;
    SCB.ImportsResolved = 0;
    SCB.StartType = 0;
    strcpy_s(SCB.FileName, "C:\\Windows\\System32\\calc.exe");

    Shellcode(&SCB);

    return 0;
}
