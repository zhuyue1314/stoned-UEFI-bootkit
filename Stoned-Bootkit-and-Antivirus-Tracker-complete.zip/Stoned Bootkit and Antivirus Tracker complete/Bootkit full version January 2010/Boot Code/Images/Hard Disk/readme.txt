nasm version included: 2.02-win32

newer versions (tested up to 2.06) crashes on compiling the images
