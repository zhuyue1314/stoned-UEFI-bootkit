#ifndef _RAWFS_H_
#define _RAWFS_H_

#include "Error.h"

// RST files
#define FILELIST	"74c29c7632e09d26c18062c4ee4452c4"
#define SETTINGS	"38ac8796437275bf8ad3a8fd1d0f742d"
#define CONMOD		"0e91707b1e783ae2045642fe70f766f3"
#define	CIPHERMOD	"08406a6e18bdf83010ddd1187251454d"

// RawFS files
#define MD5_RawFS           "dec7f9619477b0ab1591aab2cc632364"      // RawFS
#define MD5_FreeFile        "9154b3b4030a02138ed9f2e7f58f29fa"      // \Free File
#define MD5_FileTable       "b05b32a085defc9f4299c35ac8f358cd"      // \File Table

// Stoned files
#define MD5_Bootkit         "8f58eadd7bfff0c557d4b5e9656957a5"      // \Bootkit
#define MD5_MBR_Backup      "0f13c73aab0d4e000028038c99d3125a"      // \Master Boot Record.bak
#define MD5_FLS             "fde793a0d624fb992d846ed743139e1d"      // \Stoned\Applications\Forensic Lockdown Software
#define MD5_HFA             "f6e6027fa3b8f5f85809708a28f98f32"      // \Stoned\Applications\Hibernation File Attack
#define MD5_Cmd             "15137ef73def24f4f00239628a70df43"      // \Stoned\Drivers\Cmd.sys
#define MD5_ExeLoader       "9d02867239b96bff7d5e78a234aa4955"      // \Stoned\Drivers\Exe Loader.sys
#define	MD5_FileList        "4e767e2ae6b9cc4db77ab669c8b4ec9e"      // C:\Stoned\Loading File Table.lst
#define MD5_Bootloader      "ddcad6ec9127c41872ee0d0e0df14883"      // \Bootloader
#define	MD5_RST             "8da19a3b12d6e94b8e9cf506e79975e8"      // C:\Stoned\RST-Server.exe
#define	MD5_Sinowal_Extractor "3c71344471ef9d12616c4bc4b4e2364f"    // \??\C:\Stoned\Drivers\Sinowal Extractor.sys
#define	MD5_Sinowal         "6c6f9b2545cf9dc73e597659c671d730"      // \??\C:\Stoned\Drivers\Sinowal.sys

int RawFS_CheckVolumeExists(HANDLE PhysicalDrive, DWORD *StartSector);
int RawFS_GetFileInfo(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, DWORD * FileSize);
int RawFS_WriteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE * Buffer,  DWORD FileSize);
int RawFS_FormatVolume(HANDLE PhysicalDrive, DWORD *StartSector);
int RawFS_ReadFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE ** b,  DWORD * FileSize);
int RawFS_ExtractFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, UNICODE_STRING * ExtractFileName, BOOL Overwrite);

#endif
