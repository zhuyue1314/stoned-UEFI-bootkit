
/* Function error codes, returned as simple integer */
#define Error_Windows           0       // General Windows error
#define RawFS_Successful        2       // No error
#define RawFS_Corrupt_Volume    3       // RawFS file system is damaged
#define RawFS_File_Not_Found    4       // File not found
#define RawFS_Not_Bootable      5       // Volume cannot be formated with RawFS, it is not a hard disk
#define RawFS_Not_Installed     6       // Volume not formatted with RawFS
