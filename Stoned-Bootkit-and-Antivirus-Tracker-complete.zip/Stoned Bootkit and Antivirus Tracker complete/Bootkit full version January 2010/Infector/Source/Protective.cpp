
#define Stage_0_Key     0x11
#define Stage_1_Key     'Pich'//lmayr


/* general easy encryption for the header */

void Crypt_Stage0(BYTE * Buffer, int Size)
{
    for (int n = 0; n < Size; n++)
    {
        *(Buffer + n) ^= Stage_0_Key;
    }
}

void Derypt_Stage0(BYTE * Buffer, int Size)
{
    for (int n = 0; n < Size; n++)
    {
        *(Buffer + n) ^= Stage_0_Key;
    }
}


/* encyption for the file contents */

void Crypt_Stage1(BYTE * Buffer, int Size, FileAttachmentHeader * Header)
{
    Header->Key = Stage_1_Key;

    for (int n = 0; (n + 3) < Size; n += 4)
    {
        *(DWORD *)((BYTE *)Buffer + n) ^= (DWORD)Stage_1_Key;
    }
}

void Decrypt_Stage1(BYTE * Buffer, int Size, FileAttachmentHeader * Header)
{
    Header->Key = Stage_1_Key;

    for (int n = 0; (n + 3) < Size; n += 4)
    {
        *(DWORD *)((BYTE *)Buffer + n) ^= (DWORD)Stage_1_Key;
    }
}

