
/* Function error codes, returned as simple integer */
#define Error_Windows           0       // General Windows error
#define RawFS_Successful        2       // No error
#define RawFS_Corrupt_Volume    3       // RawFS file system is damaged
#define RawFS_File_Not_Found    4       // File not found
#define RawFS_Not_Bootable      5       // Volume cannot be formated with RawFS, it is not a hard disk
#define RawFS_Not_Installed     6       // Volume not formatted with RawFS

/* User error message mappings to language */
#define UserError_FailBootDrive         0
#define UserError_DriveNotBootable      1
#define UserError_FailFormatRawFS       2
#define UserError_WriteBootSector       3
#define UserError_DriveOpenError        4
#define UserError_UnknownArgument       5
#define UserError_RestoreBootSector     6
#define UserError_RemoveVolume          7
#define UserError_ExtractFileToRawFS    8
#define UserError_GetModule             9
#define UserError_OpenThisFile          10
#define UserError_ReadThisFile          11
#define UserError_GetFileSize           12
#define UserError_AllocFileBuffer       13
