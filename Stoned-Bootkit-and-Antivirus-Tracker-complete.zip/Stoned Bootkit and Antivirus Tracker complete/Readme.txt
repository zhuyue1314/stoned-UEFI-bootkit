Stoned Bootkit      31 January 2010 (version "Stoned Bootkit 2 Alpha 4" code name "Whistler")
AV Tracker 1        19.10.2009
AV Tracker 1.1      26.02.2010
AV Tracker 1.2      05.06.2010
AV Tracker 1.3      20.08.2010

Who had access?

Before the Black Hat security talk only anti-virus researchers and security companies. In late 2009 and early 2010 the source leaked,
3rd parties used it ("Whistler Bootkit" forum entries..) and was as reaction pulled of from SourceForge in January 2010 completely.

Parts of the Stoned Bootkit were always open source to the general public. AV Tracker was always completely open source

Was the bootkit source ever sold?

No. It never went out of the stage of a research project and 0,0 Euro was earned with it.

Is it valuable?

Not anymore my dear, not since more 64-bit machines are sold than 32-bit ones. This means that the Stoned Bootkit does NOT work on at
least 60% of newly sold computers. It is a battered an old hat. In the security industry there exist more advanced rootkits like TDL4.

